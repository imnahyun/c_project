#include<stdio.h>
#include<windows.h>
#include<conio.h>
#include<time.h>
#include<stdbool.h>
#include <stdlib.h.>
#include <string.h>
#include <mmsystem.h>



#pragma comment(lib, "winmm.lib")


//1
wchar_t* charToWChar(const char* str);


//2
void playMusic(const char* fileName);


//3
void printTxtFile(const char* fileName);


//4
void read_and_sort_dino_data();


//5
void dinoscore();


//6
void menu();
