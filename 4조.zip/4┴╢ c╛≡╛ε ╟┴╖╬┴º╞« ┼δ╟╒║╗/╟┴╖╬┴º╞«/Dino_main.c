#include"Dino_head.h"

int main()
{
	Dino_play();
	return 0;
}